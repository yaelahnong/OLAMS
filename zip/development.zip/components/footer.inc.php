<footer class="footer bg-dark">
  <div class="container-fluid">
    <div class="row text-muted">
      <div class="col-12 text-center">
        <p class="mb-0">
          <a class="text-muted" target="_blank"><strong class="text-white">Copyright &copy; 2023 PKL Adi Sanggoro</strong></a>
        </p>
      </div>
    </div>
  </div>
</footer>