<script src="javascripts/bootstrap.min.js"></script>
<script src="javascripts/popper.min.js"></script>
<script src="javascripts/app.min.js"></script>
<script src="javascripts/custom.js"></script>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
<script src="library/DataTables/datatables.min.js"></script>